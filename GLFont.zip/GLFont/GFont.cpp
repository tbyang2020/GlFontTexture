

#include "freetype/ftglyph.h"


#include <Windows.h>
#include <assert.h>

#include <gl/GLU.h>

//#include "glew.h"
//#include <assert.h>
//#include <math.h>
//#pragma comment(lib,"opengl32.lib")

#include <math.h>

#include "Interface3D/qTrace.h"
 


//  �洢��ǰ�ַ��������ϵ�����λ��.  6�� float  

struct  ChrTex{    

wchar_t ch;              // �ַ�����  
UINT texId=0;            // �������� ID 

float chrW=0, chrH=0;   
float texW=0, texH=0;    // ������������Ҫ offset 


// �������-- ch �Ĳ�ͬ�����ļ��������С�ȵ�, ��Ӧ��ͬ����
int FontType;            // 0,1,2,3...��Ӧ��ͬ�ļ��� .ttf �ļ�
int FontSize;            // �����ַ�����ʱָ��  




// ��������ֻ��Ϊ�˼��� FontTexture ��ĳ�Ա���������� 

float  tx0=0, ty0=0, tx1=10, ty1=10;    // Font texture quad.  // unsigned int   x1:10;
float offsetX=0,   offsetY=0;           // ?    


// float  x=0, y=0, w=10, h=10;            // Display square, Ĭ���� texture quad��ͬ.   hĬ��Ϊ _fontSize. 

};


ChrTex getChrTex(int ch, int fontSize=16, int FontType=0){

static ChrTex* g_ChrTex=0;     // ά��һ����̬�����б�. ch=0 �ǽ�β��־ . 
if(g_ChrTex==0) {  g_ChrTex=(ChrTex*)malloc(1*sizeof(ChrTex));  g_ChrTex[0].ch=0; }     // β��Ԫ�� 


ChrTex rt; rt.ch=0; 

// ������̬�б� g_ChrTex, ���� ch �� texure �����Է��� 

ChrTex*p=g_ChrTex;


while(p->ch!=0){
if(ch==p->ch){ rt=*p; break; } 
p++;
}

if(rt.ch==ch) return rt;  






// û�з��� ch �� texure �򴴽� rt�����侲̬�б� g_ChrTex�������½� rt. 

#if CREATE_CHRTEX|1

const char*q="default.ttf";    // ������ .sln ��ͬһ��Ŀ¼! 

switch(FontType){
case 1: q=""; break;
case 2: q=0;  break; 
// ...... 
default: break; 
}


static FT_Face     _face=0; 
static FT_Library  _library=0;    // static ? 

if(_face==0){
    FT_Init_FreeType( &_library );        assert(_library != 0 );
    FT_New_Face(_library,q,0,&_face);        assert(_face != 0 );
}


FT_Set_Char_Size( _face, fontSize << 6, fontSize << 6, 72, 72);  // a<<6= a*64   fontSize=16
FT_Load_Glyph( _face, FT_Get_Char_Index( _face, ch ), FT_LOAD_DEFAULT );

FT_Glyph glyph; FT_Get_Glyph( _face->glyph, &glyph );
FT_Glyph_To_Bitmap( &glyph, ft_render_mode_normal, 0, 1 );
FT_BitmapGlyph bitmap_glyph = (FT_BitmapGlyph)glyph;
FT_Bitmap& bitmap   =   bitmap_glyph->bitmap;


rt.ch=ch;
rt.FontSize=fontSize;
rt.FontType=FontType;

// rt.chrH=rt.chrW=0; rt.texH=rt.texW=0;  

rt.texId=0;  // -1

                rt.tx0       =   0;
                rt.ty0       =   0;
                rt.tx1       =   bitmap.width;
                rt.ty1       =   bitmap.rows;
                rt.offsetY   =   0;
                rt.offsetX   =   0;

 rt.texW= bitmap.width;  
 rt.texH= bitmap.rows;



   
   // if(bitmap.width == 0 || bitmap.rows == 0){ return rt; }
      


    if (bitmap.width != 0 && bitmap.rows != 0){               //  ?�ո�  û������  

                    
                rt.offsetY  =   bitmap_glyph->top;
                rt.offsetX  =   bitmap_glyph->left;

                glGenTextures(1,&rt.texId);
                glBindTexture(GL_TEXTURE_2D,rt.texId);


//    qTrace("w=%d, h=%d, ch->texId=%d", bitmap.width,bitmap.rows,  rt.texId);






        //   ָ�������ķŴ�,��С�˲���ʹ�����Է�ʽ������ͼƬ�Ŵ��ʱ���ֵ��ʽ 
        //  glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);
        
        
        glPixelStorei (GL_UNPACK_ALIGNMENT, 1);  
                
        glTexImage2D( 
            GL_TEXTURE_2D,      //! ָ���Ƕ�άͼƬ
            0,                  //! ָ��Ϊ��һ��������������mipmap,��lod,����ľͲ��ü����ģ�Զ��ʹ�ý�С������
            GL_ALPHA,           //! ������ʹ�õĴ洢��ʽ
            bitmap.width,
            bitmap.rows,
            0,                  //! �Ƿ���� The width of the border. Must be either 0 or 1.  
            GL_ALPHA,           //! ���ݵĸ�ʽ. bmp�� windows ����ϵͳ�д洢��������bgr��ʽ
            GL_UNSIGNED_BYTE,   //! ������8bit����
            bitmap.buffer                   // λͼ 
            );


            int ic=0;  
            p=g_ChrTex; 
            while(p->ch!=0){ic++; p++;}

            g_ChrTex=(ChrTex*)realloc( g_ChrTex, (ic+2)*sizeof(ChrTex) );  
            g_ChrTex[ic]=rt; 
            g_ChrTex[ic+1].ch=0;  
            
            
    }   // if !=0 

     

#endif  // CREATE_CHRTEX  


return rt;
}



// ���� size û��ʹ��, ��Ϊ _fonSize 
   
 void drawChar(float &x, float&y, UINT wch, int fontSize=16, float* color=0L, UINT fontType=0){




ChrTex  cht  =   getChrTex(wch, fontSize, fontType);


ChrTex*ch=&cht;



//int w  = ch->tx1 - ch->tx0,   h = ch->ty1 - ch->ty0 ;

int w  = ch->texW,   h = ch->texH;



//float  offsetX = ch->offsetX,    offsetY = h - ch->offsetY;
       

      
      //if(offsetY!=0) qTrace("offsetY=%f", offsetY); 

float yStart=y+fontSize;  

       
float co[4]={0}; 
glGetFloatv(GL_CURRENT_COLOR,co); 



     

     if(color)glColor3fv(color); 
                         



float vert[4*5]={   // 3����������, 2 ����������. zStart=-1

x,     yStart+ 0 - ch->offsetY,   0,   0,  0,   //        (0,-h) ---->  (w,-h)     (0,0)-->(1,0)
x+w,   yStart+ 0 - ch->offsetY,   0,   1,  0,   //                        |                 |
x+w,   yStart+ h - ch->offsetY,   0,   1,  1,   //                        |                 |
x,     yStart+ h - ch->offsetY,   0,   0,  1,   //         (0,0) <----   (w, 0)     (0,1)<--(1,1) 

};  
            
int vc=4;

//qTrace("w=%d, h=%d, ch->texId=%d", w,h,  ch->texId);
                
        glBindTexture(GL_TEXTURE_2D,ch->texId);

        glEnableClientState(GL_VERTEX_ARRAY);
        glEnableClientState(GL_TEXTURE_COORD_ARRAY);
      
        glVertexPointer(3,GL_FLOAT,5*sizeof(float),vert);
        glTexCoordPointer(2,GL_FLOAT, 5*sizeof(float),&(vert[3]));
        glDrawArrays(GL_QUADS,0,vc);



         //   xStart  +=  w + (ch->offsetX);
         x+= w +  ch->offsetX;   

              
       
       if(color)glColor3fv(co); 


}





// renderChar, ���ַ� wch ��Ⱦ�� quad. Ҫ��ͶӰ���Ĳ��� ��    
// quad �� 4��3ά�� 
  
  
 void renderChar(UINT wch, float*quad=0,  int fontSize=16, float* color=0L, UINT fontType=0){
 
ChrTex  cht  =   getChrTex(wch, fontSize, fontType);


ChrTex*ch=&cht;

int w  = ch->texW,   h = ch->texH;
       
float co[4]={0}; 
glGetFloatv(GL_CURRENT_COLOR,co); 

    
if(color)glColor3fv(color); 
                         

float x=0, y=0.5; 

float vert[4*3]={   // 4������, ��ΪĬ�� quad, ����   

x,      y - ch->offsetY,      -1.5,     
x+w,    y - ch->offsetY,      0,   
x+w,    y+ h - ch->offsetY,   0,  
x,      y+ h - ch->offsetY,   1.5,   

};  


if(!quad) quad=vert; 


//float texv[4*2]={ 0,0,    1,0,    1,1,    0,1, };    // ��������  
float texv[4*2]={ 0,1,    1,1,    1,0,   0,0    };    // ��������  

  
float*p=quad, *q=texv;  

int vc=4;

//qTrace("w=%d, h=%d, ch->texId=%d", w,h,  ch->texId);

glBindTexture(GL_TEXTURE_2D,ch->texId);



glBegin( GL_QUADS ); 

    for(int i = 0; i < vc; i++){
      glTexCoord2fv(q);   // ע��ѭ�� ... 
      glVertex3fv(p);
      p+=3;  q+=2; 
    }  // for  

glEnd();
      

if(color)glColor3fv(co); 

}



// simplex, 3ά����, ���������� 4 ��.

void renderText(float* simplex, const wchar_t*fmt, ...) {

    if (!fmt)return ;  if (*fmt == 0) return ;

    if(!simplex) return; 

    float size = 16; // 12.0f -- 's'
    float co[4] = { 0, 0, 0.0, 1, };  // ������ (., ., ., 1)  //  Ĭ����ɫ 
    int font = 0;  // FT_DEFAULT;
    int align = 1;  // TEXT_ALIGN_LEFT;   // =1  


static wchar_t gsz[1024]; *gsz = 0;  // ���߳̿��ܻ�����쳣 

va_list v; va_start(v, fmt); vswprintf(gsz, fmt, v); va_end(v);


wchar_t *p = gsz - 1;

#if PARSE_CMD|1


    do {

        p++; if (*p == 0) break;

        if (*p == 0) break;

        if (*p != '/') { continue; }

        p++; if (*p == 0) break;

        if (*p == 'f') { p++;  font = wcstol(p,0,10);   while (*(p + 1) == 0x20 || isdigit(*(p + 1)))p++;        continue; }

        if (*p == 'A') { align = wcstod(p + 1,0);  while (*(p + 1) == 0x20 || *(p + 1) == '-' || *(p + 1) == '.' || iswdigit(*(p + 1)))p++;  continue; }
        if (*p == 's') { size  = wcstod(p + 1,0);  while (*(p + 1) == 0x20 || *(p + 1) == '-' || *(p + 1) == '.' || iswdigit(*(p + 1)))p++;  continue; }


        if (*p == 'r') { co[0] = wcstod(p + 1,0); while (*(p + 1) == 0x20 || *(p + 1) == '-' || *(p + 1) == '.' || iswdigit(*(p + 1)))p++;  continue; }
        if (*p == 'g') { co[1] = wcstod(p + 1,0); while (*(p + 1) == 0x20 || *(p + 1) == '-' || *(p + 1) == '.' || iswdigit(*(p + 1)))p++;  continue; }
        if (*p == 'b') { co[2] = wcstod(p + 1,0); while (*(p + 1) == 0x20 || *(p + 1) == '-' || *(p + 1) == '.' || iswdigit(*(p + 1)))p++;  continue; }
        if (*p == 'a') { co[3] = wcstod(p + 1,0); while (*(p + 1) == 0x20 || *(p + 1) == '-' || *(p + 1) == '.' || iswdigit(*(p + 1)))p++;  continue; }

    } while (*p);


#endif  // PARSE_CMD

// if (size<16) size=16; 

 
#if BEGIN_TEXT|1
        //glDisable(GL_LIGHTING);
        //glDisable(GL_DEPTH_TEST);
        glEnable(GL_TEXTURE_2D);
        glEnable(GL_BLEND); glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

#endif  // BEGIN_TEXT


 
int ic=0; 
p= gsz;    while(*p){ p++; if(*p=='/'){*p=0; break;} ic++; }  // ��ȥ��ʽ���� 

if(ic==0) return;



float q[4*3];   // 4������, ��ΪĬ�� quad  
memcpy(q,simplex, 4*3*sizeof(float));

// ƽ������   u =��P1-P0)/ic
float ux=q[1*3+0]-q[0*3+0],    uy=q[1*3+1]-q[0*3+1],  uz=q[1*3+2]-q[0*3+2];  
ux/=ic; uy/=ic; uz/=ic;


// ƽ������   v =��P2-P3)/ic
float vx=q[2*3+0]-q[3*3+0],    vy=q[2*3+1]-q[3*3+1],  vz=q[2*3+2]-q[3*3+2];  
vx/=ic; vy/=ic; vz/=ic;

 
//  quad = p0, p0+u, p3+v, p3  ��0��   
q[1*3+0]=q[0*3+0]+ux;    // p1=p0+u
q[1*3+1]=q[0*3+1]+uy; 
q[1*3+2]=q[0*3+2]+uz; 


q[2*3+0]=q[3*3+0]+vx;    // p2=p3+v
q[2*3+1]=q[3*3+1]+vy; 
q[2*3+2]=q[3*3+2]+vz; 



    p = gsz;

    ic=0;  
    while (*p) {
    renderChar(*p,q,size,co,font); 
    
    ic++; 

//   p0+=u, p1+=u, p3+=v, p2+=v ......  ��ic ��   
     
q[0*3+0] += ux;    // p0+=u
q[0*3+1] += uy; 
q[0*3+2] += uz; 


q[1*3+0] += ux;    // p1+=u
q[1*3+1] += uy; 
q[1*3+2] += uz; 

q[2*3+0] += vx;    // p2+=v
q[2*3+1] += vy; 
q[2*3+2] += vz; 

q[3*3+0] += vx;    // p3+=v
q[3*3+1] += vy; 
q[3*3+2] += vz; 



    
    p++;
    }  // while(*ptr) 

 

return ;

}  // renderText 






















#if GTEXTOUT_COMMENT

// (x,y), ��Ļλ��, ����ֵ. 

// fmt, ����ʾ�ı������ʽ, ����c���������и�ʽ,  ����/x%f. ��ʽ��Ǳ��������, ��ȥ, ������ʾ.  

// Ŀǰ֧�����»�����ʽ:  
// %s, ����ʾ�ַ���. ���û��ǰ׺��ʽ, ��c���Ե������ʽ. ע��, ����"/n","//"֮��, ������ʽ���ر����ڴ���ʾ�ַ���֮��. 
// /f font, ����, ���� /f0
// /r����, �ı�ǰ��ɫ��ɫ����, float   
// /g����, �ı�ǰ��ɫ��ɫ���� 
// /b����, �ı�ǰ��ɫ��ɫ���� 
// /a����, �ı�ǰ��ɫ alpha ���� 
// /A. text align mode:  0 right, 1 left,  2 center 
// /s, font size, float.
// /n, ����
// ע��, vsprintf Ҫ�����������븡����. ���� 0, 0.�ǲ�ͬ��! 
// ��: ��ʾ"����.", ����Ϊ FONT_COLOBOT=0, ��ɫΪ(1,1,0,1). 
// glzTextOut(0,0,"����./f%d/r1/b1/a1", FONT_COLOBOT); 

#endif  // GTEXTOUT_COMMENT 



float gTextOut(float x, float y, const wchar_t*fmt, ...) {

    if (!fmt)return 0;  if (*fmt == 0) return 0;


    float size = 16; // 12.0f -- 's'
    float co[4] = { 0, 0, 0.0, 1, };  // ������ (., ., ., 1)  //  Ĭ����ɫ 
    int font = 0;  // FT_DEFAULT;
    int align = 1;  // TEXT_ALIGN_LEFT;   // =1  


static wchar_t gsz[1024]; *gsz = 0;  // ���߳̿��ܻ�����쳣 

va_list v; va_start(v, fmt); vswprintf(gsz, fmt, v); va_end(v);


wchar_t *p = gsz - 1;

#if PARSE_CMD|1


    do {

        p++; if (*p == 0) break;

        if (*p == 0) break;

        if (*p != '/') { continue; }

        p++; if (*p == 0) break;

        if (*p == 'f') { p++;  font = wcstol(p,0,10);   while (*(p + 1) == 0x20 || isdigit(*(p + 1)))p++;        continue; }

        if (*p == 'A') { align = wcstod(p + 1,0);  while (*(p + 1) == 0x20 || *(p + 1) == '-' || *(p + 1) == '.' || iswdigit(*(p + 1)))p++;  continue; }
        if (*p == 's') { size  = wcstod(p + 1,0);  while (*(p + 1) == 0x20 || *(p + 1) == '-' || *(p + 1) == '.' || iswdigit(*(p + 1)))p++;  continue; }


        if (*p == 'r') { co[0] = wcstod(p + 1,0); while (*(p + 1) == 0x20 || *(p + 1) == '-' || *(p + 1) == '.' || iswdigit(*(p + 1)))p++;  continue; }
        if (*p == 'g') { co[1] = wcstod(p + 1,0); while (*(p + 1) == 0x20 || *(p + 1) == '-' || *(p + 1) == '.' || iswdigit(*(p + 1)))p++;  continue; }
        if (*p == 'b') { co[2] = wcstod(p + 1,0); while (*(p + 1) == 0x20 || *(p + 1) == '-' || *(p + 1) == '.' || iswdigit(*(p + 1)))p++;  continue; }
        if (*p == 'a') { co[3] = wcstod(p + 1,0); while (*(p + 1) == 0x20 || *(p + 1) == '-' || *(p + 1) == '.' || iswdigit(*(p + 1)))p++;  continue; }

    } while (*p);


#endif  // PARSE_CMD

// if (size<16) size=16; 


#if BEGIN_TEXT|1



#if DIVERT_MATRIX 


static float g_mProj[16] = { -100, };
    
if (g_mProj[0] == -100) {

        glMatrixMode(GL_PROJECTION); glLoadIdentity();  //  Ĭ�� 
        // glOrtho(-1, 1,   -1, 1, -1, 1);       // ����ϵͳĬ�ϵ� -- ���Բ����� glView.  ��ȷ����ƶ�������! 
        glOrtho(0, 1, 0, 1, -1, 1);       // ���� Colobot ��Ĭ��ֵ    
        glGetFloatv(GL_PROJECTION_MATRIX, g_mProj);

} // if -100 



    glDisable(GL_DEPTH_TEST);  // m_device->SetRenderState(RENDER_STATE_DEPTH_TEST, false);  // ����
    glMatrixMode(GL_PROJECTION);  glLoadMatrixf(g_mProj);
    

#endif  // DIVERT_MATRIX

    glEnable(GL_BLEND); glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);       // m_device->SetBlendFunc(BLEND_SRC_ALPHA, BLEND_INV_SRC_ALPHA);
               
//\\ int aT = -1;   if (getMultiTextureEnabled()) {  glGetIntegerv(GL_ACTIVE_TEXTURE, &aT);   glActiveTexture(GL_TEXTURE0 + 0);    }  //@ ����! -- ת�Ƶ� (����) glzTextOut, Ч�ʱȽϸ�


// if (((CGLDevice*)m_engine->m_device)->m_multitextureAvailable)  glActiveTexture(GL_TEXTURE0 + 0);
    glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE); // SetTextureStageParams,  UpdateTextureParams 
    // ������ʱ����ʾָ����ɫ.  // glGetTexEnviv(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, *iv);  // iv=GL_MODULATE, GL_COMBINE
    
    bool bT = glIsEnabled(GL_TEXTURE_2D);  if(!bT) glEnable(GL_TEXTURE_2D); // in DrawPrimitive ...... 

    bool bL = glIsEnabled(GL_LIGHTING);  if (bL) glDisable(GL_LIGHTING);


#endif  // BEGIN_TEXT




    p= gsz;
    while(*p){ p++; if(*p=='/'){*p=0; break;} }  // ��ȥ��ʽ���� 


    p = gsz;

    while (*p) {    
        drawChar(x, y, *p, size, co, font);
        p++;
    }  // while(*ptr) 


#if END_TEXT|1

 //if(getMultiTextureEnabled())
    // if (aT > 0) glActiveTexture(aT);  // �� DrawChar ת�� 

    if (bL) glEnable(GL_LIGHTING);


    if(!bT) glDisable(GL_TEXTURE_2D); 

#endif    // END_TEXT


return x;
}  // glzTextOut
























class   TextureFont{

protected:

    ChrTex   _character[1<<16];   // 65536  

    FT_Library  _library;
    FT_Face     _face; 
    unsigned    _textureId;

    int         _xStart, _yStart;



public:

    int         _fontSize;  // �ƺ������ַ��߶�


    TextureFont(const char* fontFile,int fontSize)
    {

        _fontSize   =   fontSize;
        _xStart     =   0;
        _yStart     =   0;

        FT_Init_FreeType( &_library );        assert(_library != 0 );

        FT_New_Face(_library,fontFile,0,&_face);        assert(_face != 0 );

        FT_Set_Char_Size( _face, fontSize << 6, fontSize << 6, 72, 72);  // a<<6= a*64   fontSize=16


        
        glGenTextures(1,&_textureId);
        glBindTexture( GL_TEXTURE_2D, _textureId );

        //   ָ�������ķŴ�,��С�˲���ʹ�����Է�ʽ������ͼƬ�Ŵ��ʱ���ֵ��ʽ 
        //  glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);


        
        glTexImage2D( 
            GL_TEXTURE_2D,      //! ָ���Ƕ�άͼƬ
            0,                  //! ָ��Ϊ��һ��������������mipmap,��lod,����ľͲ��ü����ģ�Զ��ʹ�ý�С������
            GL_ALPHA,           //! ������ʹ�õĴ洢��ʽ
            1024,
            1024,
            0,                  //! �Ƿ�ı�
            GL_ALPHA,           //! ���ݵĸ�ʽ. bmp�� windows ����ϵͳ�д洢��������bgr��ʽ
            GL_UNSIGNED_BYTE,   //! ������8bit����
            0                   // ��λͼ 
            );

    
    
    
     
     memset(_character,0,sizeof(_character));

    
    
    }








    ChrTex*  getChrTex(wchar_t ch) {


        if (_character[ch].tx0 == 0 &&
            _character[ch].tx0 == 0 &&
            _character[ch].tx1 == 0 &&
            _character[ch].ty1 == 0
            )
        {    //  ˵���ַ���û�л��Ƶ������ϣ�����л���
            
            if (_xStart + _fontSize > 1024){  _xStart = 0;     _yStart +=  _fontSize; }            //  д��һ��,���¿�ʼ.  y��ʼλ��Ҫ����
                
    
            FT_Load_Glyph( _face, FT_Get_Char_Index( _face, ch ), FT_LOAD_DEFAULT );
            FT_Glyph glyph;
            FT_Get_Glyph( _face->glyph, &glyph );
            FT_Glyph_To_Bitmap( &glyph, ft_render_mode_normal, 0, 1 );
            FT_BitmapGlyph bitmap_glyph = (FT_BitmapGlyph)glyph;
            FT_Bitmap& bitmap   =   bitmap_glyph->bitmap;

            
            if (bitmap.width == 0 || bitmap.rows == 0)   {            //   ���û������, ��д, ֱ�ӹ�ȥ

                _xStart +=  _fontSize/2;

                _character[ch].tx0       =   _xStart;
                _character[ch].ty0       =   _yStart;
                _character[ch].tx1       =   _xStart + bitmap.width;
                _character[ch].ty1       =   _yStart + bitmap.rows;
                _character[ch].offsetY  =   0;
                _character[ch].offsetX  =   0;

            }
            else
            {
                glBindTexture(GL_TEXTURE_2D,_textureId);

                _character[ch].tx0       =   _xStart;                  // ����������ͼƬ�е�λ��ƫ��
                _character[ch].ty0       =   _yStart;
                _character[ch].tx1       =   _xStart + bitmap.width;   // ������λͼ��С��ͬ 
                _character[ch].ty1       =   _yStart + bitmap.rows;


        // qTrace("_fontSize=%d,  bitmap.rows=%d", _fontSize,    bitmap.rows);    // ��һ����ͬ 

            //qTrace("w=%d, h=%d, ch->texId=%d", bitmap.width,bitmap.rows, _textureId);


                _character[ch].offsetY  =   bitmap_glyph->top;
                _character[ch].offsetX  =   bitmap_glyph->left;

                glPixelStorei (GL_UNPACK_ALIGNMENT, 1);
                glTexSubImage2D (
                                GL_TEXTURE_2D,
                                0,
                                _xStart,
                                _yStart,
                                bitmap.width,
                                bitmap.rows,
                                GL_ALPHA,
                                GL_UNSIGNED_BYTE,
                                bitmap.buffer
                                );
                _xStart +=  bitmap.width + 1;
            }

            
        }



       // _character[ch].h=_fontSize;  // �ַ��߶� 


        return  &_character[ch];
    }
   





   // void DrawChar(float &x, float&y, UTF8Char ch, FontType font, float size, float* color){ 


   // ���� size û��ʹ��, ��Ϊ _fonSize 
   
 void drawChar(float &x, float&y, UINT wch, float size=16, float* color=0L, UINT fontType=0){


float  texWidth = 1024,  texHeight = 1024;

ChrTex*  ch  =   getChrTex(wch);

int w  = ch->tx1 - ch->tx0,   h = ch->ty1 - ch->ty0 ;
//float  offsetX = ch->offsetX,    offsetY = h - ch->offsetY;
       

      
      //if(offsetY!=0) qTrace("offsetY=%f", offsetY); 

float yStart=y+_fontSize;  

       
float co[4]={0}; 
glGetFloatv(GL_CURRENT_COLOR,co); 



     

     if(color)glColor3fv(color); 
                         



float vert[4*5]={   // 3����������, 2 ����������. zStart=-1

x,     yStart+ 0 - ch->offsetY,   0,   ch->tx0/texWidth,  ch->ty0/texHeight,   //        (0,-h) ---->  (w,-h)     (0,0)-->(1,0)
x+w,   yStart+ 0 - ch->offsetY,   0,   ch->tx1/texWidth,  ch->ty0/texHeight,   //                        |                 |
x+w,   yStart+ h - ch->offsetY,   0,   ch->tx1/texWidth,  ch->ty1/texHeight,   //                        |                 |
x,     yStart+ h - ch->offsetY,   0,   ch->tx0/texWidth,  ch->ty1/texHeight,   //        (0,0) <----   (w, 0)     (0,1)<--(1,1) 

};  
            
int vc=4;

        glEnableClientState(GL_VERTEX_ARRAY);
        glEnableClientState(GL_TEXTURE_COORD_ARRAY);
      
        glVertexPointer(3,GL_FLOAT,5*sizeof(float),vert);
        glTexCoordPointer(2,GL_FLOAT, 5*sizeof(float),&(vert[3]));
        glDrawArrays(GL_QUADS,0,vc);



         //   xStart  +=  w + (ch->offsetX);
         x+= w +  ch->offsetX;   

              
       
       if(color)glColor3fv(co); 


}




void    drawText(float x,float y,const wchar_t* text){

        typedef float   TextVertex[5];
        TextVertex  vert[256];
        
        float       texWidth    =   1024;
        float       texHeight   =   1024;
        float       xStart      =   x;


        float       yStart      =   y + _fontSize;



        float       zStart      =   -1;
        unsigned    index       =   0;
        float       fHeight     =   0;
       
        unsigned    nSize       =   wcslen(text);


        float color[4]={0,1,0,1};

        float*pc=0; 
        
        for (unsigned i = 0 ;i <  nSize; ++ i )
        {

        if(i==4) pc=color; 
        else pc=0;

        ::drawChar(x,y,text[i], 32,pc,0);         continue;

        
        #if BACKUP_BLOCK|0
        
        

            Character*  ch  =   getCharacter(text[i]);




           
            int         h   =   ch->y1 - ch->y0;
            int         w   =   ch->x1 - ch->x0;
            float       offset  =   (float(h) - float(ch->offsetY));
            float       offsetX =   float(ch->offsetX);
            

            /**
            *   ��һ����
            */
            vert[index + 0][0]  =   xStart;
            vert[index + 0][1]  =   yStart - h + offset;
            vert[index + 0][2]  =   zStart;
            vert[index + 0][3]  =   ch->x0/texWidth;
            vert[index + 0][4]  =   ch->y0/texHeight;
            /**
            *   �ڶ�����
            */
            vert[index + 1][0]  =   xStart + w;
            vert[index + 1][1]  =   yStart - h + offset;
            vert[index + 1][2]  =   zStart;
            vert[index + 1][3]  =   ch->x1/texWidth;
            vert[index + 1][4]  =   ch->y0/texHeight;

            /**
            *   ��������
            */
            vert[index + 2][0]  =   xStart + w;
            vert[index + 2][1]  =   yStart  + offset;
            vert[index + 2][2]  =   zStart;
            vert[index + 2][3]  =   ch->x1/texWidth;
            vert[index + 2][4]  =   ch->y1/texHeight;


            /**
            *   ���ĸ���
            */
            vert[index + 3][0]  =   xStart;
            vert[index + 3][1]  =   yStart  + offset;
            vert[index + 3][2]  =   zStart;
            vert[index + 3][3]  =   ch->x0/texWidth;
            vert[index + 3][4]  =   ch->y1/texHeight;




            index   +=  4;
            xStart  +=  w + (ch->offsetX);

                    
        #endif  // BACKUP_BLOCK

                       
        }


        // qTrace("sizeof(TextVertex)=%d", sizeof(TextVertex));

        glEnableClientState(GL_VERTEX_ARRAY);
        glEnableClientState(GL_TEXTURE_COORD_ARRAY);


        glVertexPointer(3,GL_FLOAT,sizeof(TextVertex),vert);
        glTexCoordPointer(2,GL_FLOAT,sizeof(TextVertex),&vert[0][3]);
        glDrawArrays(GL_QUADS,0,index);
    }

};









    
    
void  beginText()    {
        glPushClientAttrib(GL_CLIENT_ALL_ATTRIB_BITS);
        glPushAttrib(GL_ALL_ATTRIB_BITS);

        glMatrixMode(GL_PROJECTION);
        glPushMatrix();
        glLoadIdentity();

int vi[4];  glGetIntegerv(GL_VIEWPORT, vi);

        glOrtho(0,vi[2],vi[3],0,1,-1);


        glMatrixMode(GL_MODELVIEW);
        glLoadIdentity();
        glDisable(GL_LIGHTING);
        glDisable(GL_DEPTH_TEST);
        glEnable(GL_TEXTURE_2D);
        glEnable(GL_BLEND);
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    }

    
    
//   ������������

void  endText(){
        glPopAttrib();
        glPopClientAttrib();

        glMatrixMode(GL_PROJECTION);
        glPopMatrix();
        glMatrixMode(GL_MODELVIEW);
}






void RenderText(){

 static TextureFont*    _font=    new TextureFont("default.ttf",32);

    

 beginText();


 float x=10, y=20; 
 
             glColor3f(1,0,0);
          // _font->drawText(x+90,y,L"������������ Font Texture Test");

           gTextOut(x+90,y,L"������������ Font Texture Test/r1/s32");



           y+=_font->_fontSize; 

            glColor3f(1,1,1);
            _font->drawText(x, y,L"����������asdsdgggs");
           y+=_font->_fontSize; 

            glColor3f(0,1,0);
            _font->drawText(x, y,L"����������asdsdgggs����ʱ���Ƶ�");
           y+=_font->_fontSize; 

            glColor3f(0,0,1);
            _font->drawText(x,y,L"1234567890()2343434 �������ַ����� sdjskaldsndsaklds kpqQSDSDa");

           y+=_font->_fontSize; 

            endText();

            
            // SwapBuffers( wglGetCurrentDC() );



}











